FbApp.AppView = Backbone.View.extend({
	events : {
		"click #byName":"sortByNames",
		"click #byBirthday":"sortByBirthdays",
		"click #byPresence":"sortByPresence",
		"keydown #search":"filterBySearch",
		"keyup #search":"filterBySearch"
	},
	initialize: function(){
		this.collection.on('reset',this.render,this);
		this.$friendList = this.$el.find('.friend-list');
		this.render();
	},
	render:function(collection){
		var coll = collection|| this.collection;
		this.$friendList.empty();
		var $container = $('<div />');
		coll.forEach(function(friend){
			var view = new FbApp.FriendView({model:friend});
			$container.append(view.render().$el);
		},this);
		this.$friendList.append($container);

	},
	sortByNames : function(){
		this.collection.setSortBy('name');
	},
	sortByBirthdays: function(){
		this.collection.setSortBy('birthday');
	},
	sortByPresence: function(){
		//this.collection.sortByPresence();
		this.collection.setSortBy('presence');
	},
	filterBySearch: function(){
		this.collection.filterBySearch($('#search').val());
	}
});