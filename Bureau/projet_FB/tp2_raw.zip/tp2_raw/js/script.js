var Friend = Backbone.Model.extend({
	
});
var Friends = Backbone.Collection.extend({
	
});
var FriendView = Backbone.View.extend({
	
});


var friend = new FriendModel({});
/*var friendCollection = new FriendCollection({});
var friendView = new FriendView({});*/