FbApp.ChartView = Backbone.View.extend({
	initialize : function(){
		this.model.on('change:chartData',this.render,this);
	}
});