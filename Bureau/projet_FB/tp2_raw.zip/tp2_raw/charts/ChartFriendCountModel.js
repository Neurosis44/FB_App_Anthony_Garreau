FbApp.ChartFriendCountModel = FbApp.ChartModel.extend({
	processData : function(){
		// parcours la collection, et calcule %
		// this.collection
		console.log('Chartcount process');
	}
});