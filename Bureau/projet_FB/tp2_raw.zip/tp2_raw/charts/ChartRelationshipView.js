FbApp.ChartRelationshipView = FbApp.ChartView.extend({
	
});