FbApp.ChartRelationshipModel = FbApp.ChartModel.extend({
	processData : function(){
		console.log('ChartRelationshipModel process');
		// parcours la collection, et calcule %
		// this.collection

	}
});