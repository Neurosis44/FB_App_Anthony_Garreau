FbApp.ChartSexModel = FbApp.ChartModel.extend({
	processData : function(){
		// parcours la collection, et calcule %
		// this.collection
		console.log('ChartSexModel process')
	}
});