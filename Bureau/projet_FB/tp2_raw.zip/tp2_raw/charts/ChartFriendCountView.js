FbApp.ChartFriendCountView = FbApp.ChartView.extend({
	
});