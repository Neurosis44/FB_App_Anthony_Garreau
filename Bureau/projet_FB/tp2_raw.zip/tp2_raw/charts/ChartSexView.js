FbApp.ChartSexView = FbApp.ChartView.extend({
	
});